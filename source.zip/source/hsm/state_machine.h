#pragma once

#include <list>
#include <utility>
#include <unordered_map>
#include <string>

#include "hsm/resource.h"
#include "hsm/bitfield.h"
#include "hsm/debug.h"
#include "hsm/state.h"
#include "hsm/state_machine_factory.h"

class TiXmlNode;

namespace hsm
{
    class StateMachine
    {
    public:
        enum eStatus
        {
            Invalid,
            LoadResources,
            EnterState,
            Update,
            ExitState,
            UnloadResources
        };

        StateMachine( const schema::StateMachine& schema, StateMachineFactory* factory );
        ~StateMachine();

        void start( std::string& initial_state = std::string() );
        void restart( std::string& initial_state = std::string() );
        void stop();

        bool isStopped() const;
        bool isStarted() const;

        void update();
        void shutdown();

        StateMachineFactory* getFactory() { return m_factory; }
        const schema::StateMachine& getSchema() const { return m_schema; }

        void setTransition(const std::string& name, const std::string& message="");
        void throwException(const std::string& name, const std::string& message="");

        void setTransition(const std::string& name, const std::unordered_map<std::string, std::string>& attributes, const std::string& message = "");
        void throwException(const std::string& name, const std::unordered_map<std::string, std::string>& attributes, const std::string& message = "");

        std::list<const State*> getCurrentStates() const;
        std::list<const Resource*> getCurrentResources() const;
        std::list<const schema::Exception*> getCurrentExceptions() const;
        const schema::Transition* getCurrentTransition() const;

    private:
        void updateStatus_LoadResources();
        void updateStatus_EnterState();
        void updateStatus_Update();
        void updateStatus_ExitState();
        void updateStatus_UnloadResources();

        // utils.
        void getRequiredResources(const std::string state_name, std::list<schema::Resource>& resources) const;
        void evaluateTransition();
        void evaluateTransitionOperation(std::string& state_name_to_enter, bool& enter_state, bool& exit_state ) const;
        
        bool isSiblingState(const std::string& a, const std::string& b) const;
        bool isParentState(const std::string& a, const std::string& b) const;

        void setStatus(eStatus new_status);
        const char* statusToString(eStatus status) const;

        // debugging (extra string formating context).
        void logDebug( debug::LogLevel level, const char* format, ... ) const;

        // members.
        StateMachineFactory*                        m_factory;              // create components (resource, state, transition...).
        const schema::StateMachine&                 m_schema;               // state machine definition (loaded from xml).
        
        schema::Transition                          m_transition;           // current transition.
        schema::Transition                          m_restart;              // transition for a restart.
        std::list<schema::Exception>                m_exceptions;           // current exceptions.

        std::list<Resource*>                        m_resourcesToLoad;      // resources to load before entering a state.
        std::list<Resource*>                        m_resourcesToUpdate;    // resource stack to update.
        std::list<Resource*>                        m_resourcesToUnload;    // resources to unload before exiting a state.
        
        State*                                      m_stateToEnter;         // new state to enter.
        std::list<State*>                           m_statesToUpdate;       // state stack to update.
        State*                                      m_stateToExit;          // new state to exit.

        eStatus                                     m_status;               // current state machine status.
        std::string                                 m_statusString;         // status of the state machine (debugging).

        // lookup table utils.
        // the state bitname is a bitfield representation, of the location of the state within the hierarchy. 
        // This is unique to each state, and can be use to accelerate transition evaluations (what state to push, pop, ect... to reach the desired state).
        std::vector<const schema::State*> calculateSubStates( const schema::State* parent );
        void calculateLookupKey( const Bitfield& bitfield, const schema::State* state );
        bool calculateLookupTable();
        // lookup tables between state bitnames, and state fullnames.
        std::unordered_map<Bitfield, std::string> m_state_fullname_lookup;
        std::unordered_map<std::string, Bitfield> m_state_bitname_lookup;
    };
}