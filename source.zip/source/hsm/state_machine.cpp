
#include <algorithm>
#include <regex>
#include <iostream>
#include <iomanip>
#include <sstream>
#include <string.h>
#include <stdarg.h>
#include "TinyXML/tinyxml.h"
#include "hsm/state_machine.h"
#include "hsm/state_machine_factory.h"

namespace hsm
{
    StateMachine::StateMachine( const schema::StateMachine& schema, StateMachineFactory* factory )
        : m_schema( schema )
        , m_factory( factory )
        , m_stateToEnter( nullptr )
        , m_stateToExit( nullptr )
        , m_status(eStatus::Invalid)
    {
        if ( !calculateLookupTable() )
        {
            ASSERT_FATAL( false, "failed to build bitname lookup table." );
        }

        m_statusString = "CONSTRUCTED";
    }

    StateMachine::~StateMachine()
    {
        shutdown();
    }

    void StateMachine::logDebug(debug::LogLevel level, const char* format, ...) const
    {
        va_list args;
        va_start( args, format );
        std::string message = debug::formatString( format, args );
        va_end(args);

        std::ostringstream stream;

        if (m_statesToUpdate.empty())
        {
            stream << "[FSM] " << std::left << std::setfill(' ') << std::setw(16) << m_statusString << " " << message;
        }
        else
        {
            stream << "[FSM] " << std::left << std::setfill(' ') << std::setw(16) << m_statusString << " <" << m_statesToUpdate.front()->getSchema().m_fullname << "> " << message;
        }
        
        debug::logDebug(level, stream.str().c_str());
    }

    void StateMachine::shutdown()
    {
        m_statusString = "SHUTTING_DOWN";

        for (auto resource : m_resourcesToLoad)
            delete resource;
        m_resourcesToLoad.clear();

        for (auto resource : m_resourcesToUnload)
            delete resource;
        m_resourcesToUnload.clear();

        for (auto resource : m_resourcesToUpdate)
            delete resource;
        m_resourcesToUpdate.clear();

        for (auto state : m_statesToUpdate)
            delete state;
        m_statesToUpdate.clear();

        delete m_stateToEnter;
        m_stateToEnter = nullptr;

        delete m_stateToExit;
        m_stateToExit = nullptr;

        m_restart = schema::Transition();
        m_transition = schema::Transition();

        m_statusString = "SHUTDOWN";
        logDebug(debug::LogLevel::Trace, "Shutdown.");
    }

    // loading the schemas and initialising the states.
    void StateMachine::start( std::string& initial_state )
    {
        // already started.
        if (isStarted())
            return;

        if ( m_factory == nullptr )
        {
            logDebug( debug::LogLevel::Error, "Factory is nullptr." );
            return;
        }

        // disable restarts
        m_restart = schema::Transition();
        m_transition = schema::Transition();

        schema::Transition start_schema;
        start_schema.m_state = initial_state.empty() ? m_schema.m_initial_state : initial_state;
        start_schema.m_event = "_enter";
        m_transition = start_schema;

        evaluateTransition();

        m_status = eStatus::LoadResources;
        m_statusString = "STARTING";
    }

    // loading the schemas and initialising the states.
    void StateMachine::restart( std::string& initial_state )
    {
        if (m_factory == nullptr)
        {
            logDebug(debug::LogLevel::Error, "Factory is nullptr.");
            return;
        }

        // first, do an exit transition.
        schema::Transition stop_schema; 
        stop_schema.m_state = "";
        stop_schema.m_event = "_exit";

        m_transition = stop_schema;
        m_restart = schema::Transition();

        // second, cache a new restart transition.
        schema::Transition restart_schema;
        restart_schema.m_state = initial_state.empty() ? m_schema.m_initial_state : initial_state;
        restart_schema.m_event = "_enter";

        m_restart = restart_schema;
        m_statusString = "RESTARTING";
    }

    std::list<const Resource*> StateMachine::getCurrentResources() const
    {
        std::list<const Resource*> resources;

        for (auto resource : m_resourcesToUpdate)
        {
            resources.push_back(resource);
        }
        
        for (auto resource : m_resourcesToLoad)
        {
            resources.push_back(resource);
        }
        return resources;
    }

    std::list<const State*> StateMachine::getCurrentStates() const
    {
        std::list<const State*> states;

        for (auto state : m_statesToUpdate)
        {
            states.push_back(state);
        }

        if (m_stateToEnter != nullptr)
        {
            states.push_back(m_stateToEnter);
        }

        return states;
    }

    std::list<const schema::Exception*> StateMachine::getCurrentExceptions() const
    {
        std::list<const schema::Exception*> exceptions;

        for (const auto& ex : m_exceptions)
        {
            exceptions.push_back(&ex);
        }
        return exceptions;
    }

    const schema::Transition* StateMachine::getCurrentTransition() const
    {
        if (m_transition.m_event.empty())
            return nullptr;

        return &m_transition;
    }

    void StateMachine::stop()
    {
        // already stopped.
        if (isStopped())
            return;

        if ( m_factory == nullptr )
        {
            logDebug( debug::LogLevel::Error, "Factory is nullptr." );
            return;
        }
        
        // stop restarts.
        m_restart = schema::Transition();
        m_transition = schema::Transition();

        // generate a stopping transition.
        schema::Transition stop_schema;
        stop_schema.m_event = "_exit";
        stop_schema.m_state = "";
               
        m_transition = stop_schema;
        m_statusString = "STOPPING";
    }

    void StateMachine::setTransition(const std::string& name, const std::string& message)
    {
        std::unordered_map<std::string, std::string> attributes;
        setTransition(name, attributes, message);
    }

    void StateMachine::throwException(const std::string& name, const std::string& message)
    {
        std::unordered_map<std::string, std::string> attributes;
        throwException(name, attributes, message);
    }

    void StateMachine::setTransition(const std::string& name, const std::unordered_map<std::string, std::string>& attributes, const std::string& message)
    {
        // start updating states, from the bottom up.
        for (auto it = m_statesToUpdate.rbegin(); it != m_statesToUpdate.rend(); ++it)
        {
            auto state = *it;

            // find the transition definition.
            for (auto transition_schema : state->getSchema().m_transitions)
            {
                if (transition_schema.m_event == name && attributes == transition_schema.m_attributes)
                {
                    if (m_factory == nullptr)
                    {
                        logDebug(debug::LogLevel::Error, "Factory is nullptr.");
                    }
                    else
                    {
                        // transition found.
                        m_transition = transition_schema;
                        break;
                    }
                }
            }
        }

        if (attributes.empty())
        {
            logDebug(debug::LogLevel::Error, "couldn't find transition '%s' in current states.", name.c_str());
        }
        else
        {
            std::string str;
            std::ostringstream stream(str);
            for (auto it = attributes.begin(); it != attributes.end(); ++it)
            {
                if (it != attributes.begin())
                {
                    stream << ", ";
                }
                stream << it->first << "=" << it->second;
            }
            logDebug(debug::LogLevel::Error, "couldn't find transition '%s' [%s] in current states.", name.c_str(), str.c_str());
        }
    }

    void StateMachine::throwException(const std::string& name, const std::unordered_map<std::string, std::string>& attributes, const std::string& message)
    {
        // start updating states, from the bottom up.
        for (auto it = m_statesToUpdate.rbegin(); it != m_statesToUpdate.rend(); ++it)
        {
            auto state = *it;

            // find the transition definition.
            for (auto exception_schema : state->getSchema().m_exceptions)
            {
                if (exception_schema.m_event == name && attributes == exception_schema.m_attributes)
                {
                    if (m_factory == nullptr)
                    {
                        logDebug(debug::LogLevel::Error, "Factory is nullptr.");
                    }
                    else
                    {
                        // transition found.
                        m_exceptions.push_back(exception_schema);
                        break;
                    }
                }
            }
        }

        if (attributes.empty())
        {
            logDebug(debug::LogLevel::Error, "couldn't find transition '%s' in current states.", name.c_str());
        }
        else
        {
            std::string str;
            std::ostringstream stream(str);
            for (auto it = attributes.begin(); it != attributes.end(); ++it)
            {
                if (it != attributes.begin())
                {
                    stream << ", ";
                }
                stream << it->first << "=" << it->second;
            }
            logDebug(debug::LogLevel::Error, "couldn't find transition '%s' [%s] in current states.", name.c_str(), str.c_str());
        }
    }

    bool StateMachine::isStopped() const
    {
        // transitioning. Not finished.
        if(!m_transition.m_event.empty())
            return false;

        // transitioning. Not finished.
        if (!m_restart.m_event.empty())
            return false;

        // still states being updated.
        if (!m_statesToUpdate.empty())
            return false;

        // resources still being loaded.
        if (!m_resourcesToLoad.empty())
            return false;

        // resources still being unloaded.
        if (!m_resourcesToUnload.empty())
            return false;

        return true;
    }

    bool StateMachine::isStarted() const
    {
        return !isStopped();
    }

    void StateMachine::update()
    {
        switch (m_status)
        {
        default:
            {
                break;
            }
        case eStatus::LoadResources:
            {
                updateStatus_LoadResources();
                break;
            }
        case eStatus::EnterState:
            {
                updateStatus_EnterState();
                break;
            }
        case eStatus::Update:
            {
                updateStatus_Update();
                break;
            }
        case eStatus::ExitState:
            {
                updateStatus_ExitState();
                break;
            }
        case eStatus::UnloadResources:
            {
                updateStatus_UnloadResources();
                break;
            }
        }
    }

    void StateMachine::setStatus(eStatus new_status)
    {
        if (new_status != m_status)
        {
            switch (new_status)
            {
            default:
                {
                    ASSERT_FATAL(false, "new_status(%d) invalid.", new_status);
                    break;
                }
            case eStatus::ExitState:
                {
                    break;
                }
            case eStatus::UnloadResources:
                {
                    ASSERT_FATAL(m_stateToExit == nullptr, "m_stateToExit(%s) is not null.", m_stateToExit->getSchema().m_fullname);
                    break;
                }
            case eStatus::LoadResources:
                {
                    ASSERT_FATAL(m_stateToExit == nullptr, "m_stateToExit(%s) is not null.", m_stateToExit->getSchema().m_fullname);
                    ASSERT_FATAL(m_resourcesToLoad.empty(), "m_resourcesToLoad(%d resources) is not empty.", m_resourcesToLoad.size());
                    break;
                }
            case eStatus::EnterState:
                {
                    ASSERT_FATAL(m_stateToExit == nullptr, "m_stateToExit(%s) is not null.", m_stateToExit->getSchema().m_fullname);
                    ASSERT_FATAL(m_resourcesToLoad.empty(), "m_resourcesToLoad(%d resources) is not empty.", m_resourcesToLoad.size());
                    ASSERT_FATAL(m_resourcesToUnload.empty(), "m_resourcesToUnload(%d resources) is not empty.", m_resourcesToUnload.size());
                    break;
                }
            case eStatus::Update:
                {
                    ASSERT_FATAL(m_stateToEnter == nullptr, "m_stateToEnter(%s) is not null.", m_stateToEnter->getSchema().m_fullname);
                    ASSERT_FATAL(m_stateToExit == nullptr, "m_stateToExit(%s) is not null.", m_stateToExit->getSchema().m_fullname);
                    ASSERT_FATAL(m_resourcesToLoad.empty(), "m_resourcesToLoad(%d resources) is not empty.", m_resourcesToLoad.size());
                    ASSERT_FATAL(m_resourcesToUnload.empty(), "m_resourcesToUnload(%d resources) is not empty.", m_resourcesToUnload.size());
                    break;
                }
            }

            m_status = new_status;

            m_statusString = statusToString(m_status);
            
            logDebug(debug::LogLevel::Trace, "status set to (%s).", m_statusString);
        }
    }

    const char* StateMachine::statusToString(eStatus status) const
    {
        switch (status)
        {
        default:                        return "UNKNOWN";
        case eStatus::Invalid:          return "Invalid";
        case eStatus::LoadResources:    return "LoadResources";
        case eStatus::EnterState:       return "EnterState";
        case eStatus::Update:           return "Update";
        case eStatus::ExitState:        return "ExitState";
        case eStatus::UnloadResources:  return "UnloadResources";
        }
    } 

    void StateMachine::updateStatus_Update()
    {
        // start updating states, from the bottom up.
        for (auto it = m_statesToUpdate.rbegin(); it != m_statesToUpdate.rend(); ++it)
        {
            auto state = *it;

            state->update();

            // state fired a transition event.
            if (!m_transition.m_event.empty())
            {
                evaluateTransition();
                break;
            }
        }
    }

    void StateMachine::updateStatus_EnterState()
    {
        if (m_stateToEnter != nullptr)
        {
            std::string state_name = m_stateToEnter->getSchema().m_fullname.c_str();

            // entering next state.
            m_stateToEnter->enter();

            logDebug(debug::LogLevel::Trace, "state '%s' entered.", state_name);

            m_statesToUpdate.push_back(m_stateToEnter);

            m_stateToEnter = nullptr;
        }

        setStatus(eStatus::Update);
    }

    void StateMachine::updateStatus_ExitState()
    {
        if (m_stateToExit != nullptr)
        {
            std::string state_name = m_stateToExit->getSchema().m_fullname.c_str();

            // entering next state.
            m_stateToExit->exit();

            logDebug(debug::LogLevel::Trace, "state '%s' exited.", state_name);

            m_statesToUpdate.remove(m_stateToExit);

            delete m_stateToExit;

            logDebug(debug::LogLevel::Trace, "state '%s' deleted.", state_name);

            m_stateToExit = nullptr;
        }

        if (!m_resourcesToUnload.empty())
        {
            setStatus(eStatus::UnloadResources);
        }
        else if (!m_resourcesToLoad.empty())
        {
            setStatus(eStatus::LoadResources);
        }
        else if(m_stateToEnter != nullptr)
        {
            setStatus(eStatus::EnterState);
        }
        else
        {
            setStatus(eStatus::Update);
        }
    }

    void StateMachine::updateStatus_LoadResources()
    {
        Resource* resource = m_resourcesToLoad.empty() ? nullptr : m_resourcesToLoad.front();

        while (resource != nullptr)
        {
            switch(resource->getStatus())
            {
            default: break;
            case Resource::eStatus::Unset:
            case Resource::eStatus::Unloaded:
                {
                    resource->load();
                    return;
                }
            case Resource::eStatus::Loading:
                {
                    return;
                }
            case Resource::eStatus::Error:
            case Resource::eStatus::Loaded:
                {
                    logDebug(debug::LogLevel::Trace, "resource '%s' %s.", resource->getSchema().m_name.c_str(), resource->getStatus() == Resource::eStatus::Error ? "error" : "loaded");

                    // move to the next resource to load.
                    m_resourcesToLoad.pop_front();

                    resource = m_resourcesToLoad.empty() ? nullptr : m_resourcesToLoad.front();

                    break;
                }
            case Resource::eStatus::Unloading:
                {
                    break;
                }
            }
        }

        // loading finished.
        if (m_resourcesToLoad.empty())
        {
            // we had at least some resources to load. Tell when it's finished.
            logDebug(debug::LogLevel::Trace, "all resources loaded.");

            if (m_stateToEnter != nullptr)
            {
                setStatus(eStatus::EnterState);
            }
            else
            {
                setStatus(eStatus::Update);
            }
        }
    }

    void StateMachine::updateStatus_UnloadResources()
    {
        Resource* resource = m_resourcesToUnload.empty() ? nullptr : m_resourcesToUnload.back();

        while (resource != nullptr)
        {
            switch (resource->getStatus())
            {
            default: 
                {
                    break;
                }
            case Resource::eStatus::Loaded:
                {
                    resource->unload();
                    return;
                }
            case Resource::eStatus::Loading:
            case Resource::eStatus::Unloading:
                {
                    return;
                }
            case Resource::eStatus::Error:
            case Resource::eStatus::Unloaded:
                {
                    logDebug(debug::LogLevel::Trace, "resource '%s' %s.", resource->getSchema().m_name.c_str(), resource->getStatus() == Resource::eStatus::Error ? "error" : "unloaded");

                    // move to the next resource to load.
                    m_resourcesToUnload.pop_front();

                    resource = m_resourcesToUnload.empty() ? nullptr : m_resourcesToUnload.front();

                    break;
                }
            }
        }

        // unloading finished.
        if (m_resourcesToUnload.empty())
        {
            // we had resources to unload. Tell when it's finished.
            logDebug(debug::LogLevel::Trace, "all resources unloaded.");

            if (!m_resourcesToLoad.empty())
            {
                setStatus(eStatus::LoadResources);
            }
            else if (m_stateToEnter != nullptr)
            {
                setStatus(eStatus::EnterState);
            }
            else
            {
                setStatus(eStatus::Update);
            }
        }
    }

    void StateMachine::getRequiredResources(const std::string state_name, std::list<schema::Resource>& resources) const
    {
        auto it = m_schema.m_states.find(state_name);
        
        if (it != m_schema.m_states.end())
        {
            const schema::State& state = it->second;
        
            resources.insert(resources.begin(), state.m_resources.begin(), state.m_resources.end());

            if (!state.m_parent.empty())
            {
                getRequiredResources(state.m_parent, resources);
            }
        }
    }

    void StateMachine::evaluateTransition()
    {
        // calculate what operations required to reach the state targeted by transition.
        std::string statename_to_enter;
        bool enter_state;
        bool exit_state;
        evaluateTransitionOperation(statename_to_enter, enter_state, exit_state);

        std::list<schema::Resource> requiredResources;
        getRequiredResources(statename_to_enter, requiredResources);

        // resources to unload to jump to required state.
        for (auto resource : m_resourcesToUpdate)
        {
            const schema::Resource& res = resource->getSchema();

            auto it = std::find_if(requiredResources.begin(), requiredResources.end(), [&res](const schema::Resource& r)
            {
                return res.m_name == r.m_name;
            });

            if (it == requiredResources.end())
            {
                m_resourcesToUnload.push_back(resource);
            }
        }

        // resources to load to jump to required state.
        for (const auto& res : requiredResources)
        {
            auto it = std::find_if(m_resourcesToUpdate.begin(), m_resourcesToUpdate.end(), [&res](const Resource* r)
            {
                return res.m_name == r->getSchema().m_name;
            });

            if (it == m_resourcesToUpdate.end())
            {
                Resource* resource = m_factory->createResource(res);

                if (resource != nullptr)
                {
                    m_resourcesToLoad.push_back(resource);
                }
            }
        }

        // state to exit.
        if (exit_state)
        {
            m_stateToExit = m_statesToUpdate.back();
        }

        // state to enter.
        if (enter_state)
        {
            auto it = m_schema.m_states.find(statename_to_enter);

            if (it == m_schema.m_states.end())
            {
                logDebug(debug::LogLevel::Error, "couldn't find schema for state '%s'.", statename_to_enter.c_str());
            }
            else
            {
                const schema::State& state_schema = it->second;

                m_stateToEnter = m_factory->createState(this, state_schema);

                logDebug(debug::LogLevel::Trace, "state '%s' created.", state_schema.m_fullname);
            }
        }
    }

    bool StateMachine::isSiblingState(const std::string& a, const std::string& b) const
    {
        auto at = m_schema.m_states.find(a);
        auto bt = m_schema.m_states.find(b);
        ASSERT_SANITY(at != m_schema.m_states.end(), "failed to find state with name '%s'.", a.c_str());
        ASSERT_SANITY(bt != m_schema.m_states.end(), "failed to find state with name '%s'.", b.c_str());
        return at->second.m_parent == bt->second.m_parent;
    }

    bool StateMachine::isParentState(const std::string& a, const std::string& b) const
    {
        auto at = m_schema.m_states.find(a);
        auto bt = m_schema.m_states.find(b);
        ASSERT_SANITY(at != m_schema.m_states.end(), "failed to find state with name '%s'.", a.c_str());
        ASSERT_SANITY(bt != m_schema.m_states.end(), "failed to find state with name '%s'.", b.c_str());
        return at->second.m_parent == b;
    }

    void StateMachine::evaluateTransitionOperation(std::string& statename_to_enter, bool& enter_state, bool& exit_state) const
    {
        // default, do nothing.
        enter_state = false;
        exit_state = false;

        // reached the bottom of the state machine, and transition tries to reach the bottom.
        if (m_statesToUpdate.empty() && m_transition.m_state.empty())
            return;

        // state stack is empty. Just go to root state.
        if (m_statesToUpdate.empty())
        {
            // the state we're trying to reach is now the startup state.
            statename_to_enter = m_schema.m_initial_state;
            enter_state = true;
            return;
        }

        const std::string& current_state = m_statesToUpdate.front()->getSchema().m_fullname;
        const std::string& desired_state = m_transition.m_state;

        if (isParentState(current_state, desired_state))
        {
            statename_to_enter = m_schema.m_initial_state;
            enter_state = true;
        }

        if (isParentState(desired_state, current_state))
        {
            exit_state = true;
        }

        if (isSiblingState(current_state, desired_state))
        {
            statename_to_enter = desired_state;
            enter_state = true;
            exit_state = true;
            return;
        }

        // find state bitname we're trying to reach.
        auto it = m_state_bitname_lookup.find(desired_state);
        if (it == m_state_bitname_lookup.end())
        {
            // do nothing. maybe an error in the xml definition, so we'll be stuck here, but that's ok.
            logDebug(debug::LogLevel::Error, "could not find lookup bitfield for state '%s'.", desired_state.c_str());
            return;
        }

        // find state bitname we're currently at.
        auto jt = m_state_bitname_lookup.find(current_state);
        if (jt == m_state_bitname_lookup.end())
        {
            //. this is not ok. SHould not happen.
            logDebug(debug::LogLevel::SanityCheck, "could not find lookup bitfield for state '%s'.", current_state.c_str());
            return;
        }


        // find bitfields that identify the states we're trying to reach, and the state we're currently at.
        const Bitfield& state_to_reach = it->second;
        const Bitfield& state_current = jt->second;

        // find the bitfield that identifies the state that is common to the target and current states.
        Bitfield common_bitfield = state_to_reach & state_current;

        // still haven't reached the point in the hierarchy common to current state and desired state.
        if (common_bitfield != state_current)
        {
            exit_state = true;
            return;
        }

        // we've reached the common state. giong back up again to reach the desired state.
        for (size_t i = state_current.getNumBits(); i < state_to_reach.getNumBits(); ++i)
        {
            // stop at first bit set to true.
            // that will be the first state we need to enter.
            if (state_to_reach.getBit(i))
            {
                // generate the state bitfield we need to enter.
                common_bitfield.setBit(i, true);

                // find state name matching the bitname.
                auto it = m_state_fullname_lookup.find(common_bitfield);
                if (it == m_state_fullname_lookup.end())
                {
                    logDebug(debug::LogLevel::SanityCheck, "failed to find state matching the bitfield.");
                    return;
                }
                else
                {
                    statename_to_enter = it->second;
                    enter_state = true;
                    return;
                }
            }
        }
    }

    // calculate the list of child states for a given state.
    std::vector<const schema::State*> StateMachine::calculateSubStates(const schema::State* parent)
    {
        std::vector<const schema::State*> sub_states;

        std::string parent_name = parent->m_fullname;

        for ( auto& state_schema : m_schema.m_states )
        {
            std::string state_name = state_schema.second.m_fullname;

            size_t pos = state_name.find( parent_name );

            if (pos != 0)
                continue;

            std::string sub_state_name = state_name.substr( parent_name.size() );

            pos = sub_state_name.rfind( "\\" );

            if (pos != 0)
                continue;

            sub_states.push_back(&state_schema.second);
        }

        return sub_states;
    }

    // calculate bitfields for the state hierarchy under a state.
    void StateMachine::calculateLookupKey( const Bitfield& bitfield, const schema::State* state )
    {
        // find sub-states.
        std::vector<const schema::State*> subStates = calculateSubStates( state );

        // calculate child states bitfields.
        std::vector<Bitfield> subStateBitfields;

        // generate bitfields for each child state.
        for ( size_t i = 0; i < subStates.size(); ++i )
        {
            Bitfield subStateBitfield = bitfield;

            for ( size_t j = 0; j < subStates.size(); ++j )
            {
                bool value = (j == i) ? true : false;

                subStateBitfield.pushBit(value);
            }

            subStateBitfields.push_back(subStateBitfield);

            // store lookup entries for the child state.
            m_state_fullname_lookup[subStateBitfield] = subStates[i]->m_fullname;
            m_state_bitname_lookup[subStates[i]->m_fullname] = subStateBitfield;
        }

        // calculate further sub-states bitfields.
        for (size_t i = 0; i < subStates.size(); ++i)
        {
            calculateLookupKey(subStateBitfields[i], subStates[i]);
        }
    }

    // calculate bitfield lookup table for each satte in the state machine.
    bool StateMachine::calculateLookupTable()
    {
        // find the root.
        const std::string& root_name = m_schema.m_initial_state;

        auto it = m_schema.m_states.find(root_name);

        if (it == m_schema.m_states.end())
        {
            return false;
        }

        const schema::State* root = &(it->second);

        // root bitfield.
        Bitfield bitfield;
        bitfield.setBit(0, true);

        // add lookup entries.
        m_state_fullname_lookup[bitfield] = root_name;
        m_state_bitname_lookup[root_name] = bitfield;

        // calculate bitfields for each sub-state under the root.
        calculateLookupKey(bitfield, root);

        return true;
    }
}

