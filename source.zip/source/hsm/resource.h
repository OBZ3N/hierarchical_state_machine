#pragma once

#include <string>
#include "hsm/schema.h"

namespace hsm
{
    // blocking process that will load resources before entering a state,
    // and unload resources after exiting a state. 
    // This is useful for loading resources prior to entering a specific state.
    // the structure is a stack, what is loaded last, will be unloaded first at exit.
    // example : loading dll modules at the boot sequence, 
    // memory allocation setup, initializing the network stack, singleton creations, 
    // loading level data, ui data, ect...
    class Resource
    {
    public:
        enum eStatus
        {
            Unset,
            Loading,
            Loaded,
            Unloading,
            Unloaded,
            Error,
        };

        Resource( const schema::Resource& schema )
            : m_schema( schema )
            , m_status(eStatus::Unset)
        {}

        virtual ~Resource()
        {}

        virtual void load() = 0;
        virtual void update() = 0;
        virtual void unload() = 0;

        const schema::Resource& getSchema() const { return m_schema; }
        virtual eStatus getStatus() const { return m_status; }
        const char* statusToString(eStatus status)
        {
            switch (status)
            {
            default:                    return "INVALID";
            case eStatus::Unset:        return "Unset";
            case eStatus::Loading:      return "Loading";
            case eStatus::Loaded:       return "Loaded";
            case eStatus::Unloading:    return "Unloading";
            case eStatus::Unloaded:     return "Unloaded";
            case eStatus::Error:        return "Error";
            }
        }

        void setStatus(eStatus status, bool force=false)
        {
            if (status != m_status || force)
            {
                m_status = status;
            }
        }

    private:
        schema::Resource m_schema;
        eStatus m_status;
    };
}
