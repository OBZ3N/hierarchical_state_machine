
#include "hsm/debug.h"
#include "hsm/state_machine_xml_loader.h"


void main()
{
   exit( 0 );
}