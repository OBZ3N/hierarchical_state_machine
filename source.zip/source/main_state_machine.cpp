
#define SDL_MAIN_HANDLED

#include <windows.h>
#include <stdio.h>
#include <gl/gl.h>
#include <gl/glu.h>
#include <sdl.h>

#include "imgui/imgui.h"
#include "imgui/imgui_impl_sdl.h"
#include "imgui/imgui_impl_opengl2.h"

#include "hsm/schema.h"
#include "hsm/timer.h"
#include "hsm/random.h"
#include "hsm/resource.h"
#include "hsm/state.h"
#include "hsm/state_machine.h"
#include "hsm/state_machine_factory.h"
#include "hsm/state_machine_xml_loader.h"

#pragma comment (lib, "opengl32.lib")
#pragma comment (lib, "sdl2.lib")
#pragma comment (lib, "sdl2main.lib")

#define SCREEN_WIDTH            800
#define SCREEN_HEIGHT           600
#define OPENGL_MAJOR_VERSION    2
#define OPENGL_MINOR_VERSION    1
#define OPENGL_PROFILE          SDL_GLprofile::SDL_GL_CONTEXT_PROFILE_CORE

SDL_Window * displayWindow;
SDL_GLContext context;

hsm::StateMachine* state_machine = nullptr;
hsm::StateMachineFactory* state_machine_factory = nullptr;

class ImGuiHSMState : public hsm::State
{
public:
    ImGuiHSMState(hsm::StateMachine* parent, const hsm::schema::State& schema)
        : hsm::State(parent, schema)
        , m_running(false)
    {}

    void enter() override;
    void update() override;
    void exit() override;
    void render() const;

    void renderTransitions() const;
    void renderExceptions() const;
    bool m_running;
};

void ImGuiHSMState::enter()
{
    m_running = true;
}

void ImGuiHSMState::update()
{

}

void ImGuiHSMState::exit()
{
    m_running = false;
}

void ImGuiHSMState::render() const
{
    if (ImGui::TreeNodeEx(getSchema().m_shortname.c_str(), ImGuiTreeNodeFlags_DefaultOpen))
    {
        renderTransitions();

        ImGui::TreePop();
    }
}


void ImGuiHSMState::renderTransitions() const
{
    if (m_running)
    {
        if (ImGui::TreeNode("transitions"))
        {
            for (const auto& it : getSchema().m_transitions)
            {

                if (ImGui::Button(it.m_event.c_str()))
                {
                    state_machine->setTransition(it.m_event, it.m_attributes);
                }

                if (!it.m_attributes.empty())
                {
                    char buffer[512];
                    int bufferlen = 0;
                    bufferlen += sprintf_s(buffer + bufferlen, sizeof(buffer) / sizeof(*buffer) - bufferlen, " [");

                    for (std::unordered_map<std::string, std::string>::const_iterator jt = it.m_attributes.begin(); jt != it.m_attributes.end(); ++jt)
                    {
                        if (jt != it.m_attributes.begin())
                            bufferlen += sprintf_s(buffer + bufferlen, sizeof(buffer) / sizeof(*buffer) - bufferlen, ", ");

                        bufferlen += sprintf_s(buffer + bufferlen, sizeof(buffer) / sizeof(*buffer) - bufferlen, "%s=%s", jt->first.c_str(), jt->second.c_str());
                    }
                    
                    bufferlen += sprintf_s(buffer + bufferlen, sizeof(buffer) / sizeof(*buffer) - bufferlen, "]");

                    ImGui::SameLine();
                    ImGui::Text(buffer);
                }
            }
            ImGui::TreePop();
        }
    }
}

class ImGuiHSMResource : public hsm::Resource
{
public:
    enum eUIElement
    {
        Name,
        CommandButton,
        ErrorButton,

    };
    ImGuiHSMResource(const hsm::schema::Resource& schema )
        : hsm::Resource(schema)
    {}

    void load() override;
    void unload() override;
    void update() override;
    void render(eUIElement element);
};

void ImGuiHSMResource::load()
{
    setStatus(eStatus::Loading);
}

void ImGuiHSMResource::unload()
{
    setStatus(eStatus::Unloading);
}

void ImGuiHSMResource::update()
{
}

void ImGuiHSMResource::render(eUIElement element)
{
    switch (element)
    {
    default: break;
    case eUIElement::Name:
        {
            ImGui::Text("%s", statusToString(getStatus()));
            break;
        }
    case eUIElement::ErrorButton:
        {
            if (ImGui::Button("error"))
            {
                std::unordered_map<std::string, std::string> attributes = getSchema().m_attributes;
                attributes["name"] = getSchema().m_name;
                state_machine->throwException("resource_error", attributes);
                setStatus(eStatus::Error);
            }
            break;
        }
    case eUIElement::CommandButton:
        {
            switch (getStatus())
            {
            default: break;
            case eStatus::Loading:
                {
                    if (ImGui::Button("loaded"))
                        setStatus(eStatus::Loaded);
                    break;
                }
            case eStatus::Unloading:
                {
                    if (ImGui::Button("unloaded"))
                        setStatus(eStatus::Unloaded);
                    break;
                }
            }
            break;
        }
    }
}

class ImGuiHSMFactory : public hsm::StateMachineFactory
{
public:
    ImGuiHSMFactory()
    {}

    hsm::State* createState(hsm::StateMachine* state_machine, const hsm::schema::State& state_schema) override
    {
        return new ImGuiHSMState(state_machine, state_schema);
    }

    hsm::Resource* createResource(const hsm::schema::Resource& resource_schema) override
    {
        return new ImGuiHSMResource(resource_schema);
    }
};

class ImGuiHSMachine : public hsm::StateMachine
{
public:
    ImGuiHSMachine(const hsm::schema::StateMachine& schema, hsm::StateMachineFactory* factory)
        : hsm::StateMachine(schema, factory)
    {
    }

    void renderResources() const
    {
        if (ImGui::TreeNode("resources"))
        {
            std::list<const hsm::Resource*> resources = getCurrentResources();

            ImGui::Columns(3);

            for (auto resource : resources)
            {
                ((ImGuiHSMResource*)resource)->render(ImGuiHSMResource::eUIElement::Name);
                ImGui::NextColumn();

                ((ImGuiHSMResource*)resource)->render(ImGuiHSMResource::eUIElement::CommandButton);
                ImGui::NextColumn();

                ((ImGuiHSMResource*)resource)->render(ImGuiHSMResource::eUIElement::ErrorButton);
                ImGui::NextColumn();
            }
            ImGui::Columns(1);

            ImGui::TreePop();
        }
    }

    void renderExceptions(const std::list<const hsm::State*>& states) const
    {
        if (ImGui::TreeNode("exceptions"))
        {
            std::list<const hsm::schema::Exception*> exceptions;

            for (auto state : states)
            {
                for (const auto& exception : state->getSchema().m_exceptions)
                {
                    if (exception.m_event != "*")
                    {
                        exceptions.push_back(&exception);
                    }
                }
            }

            for (auto exception : exceptions)
            {
                if (ImGui::Button(exception->m_event.c_str()))
                {
                    state_machine->throwException(exception->m_event, exception->m_attributes);
                }

                if (!exception->m_attributes.empty())
                {
                    char buffer[512];
                    int bufferlen = 0;
                    bufferlen += sprintf_s(buffer + bufferlen, sizeof(buffer) / sizeof(*buffer) - bufferlen, " [");

                    for (std::unordered_map<std::string, std::string>::const_iterator jt = exception->m_attributes.begin(); jt != exception->m_attributes.end(); ++jt)
                    {
                        if (jt != exception->m_attributes.begin())
                            bufferlen += sprintf_s(buffer + bufferlen, sizeof(buffer) / sizeof(*buffer) - bufferlen, ", ");

                        bufferlen += sprintf_s(buffer + bufferlen, sizeof(buffer) / sizeof(*buffer) - bufferlen, "%s=%s", jt->first.c_str(), jt->second.c_str());
                    }
                    bufferlen += sprintf_s(buffer + bufferlen, sizeof(buffer) / sizeof(*buffer) - bufferlen, "]");

                    ImGui::SameLine();
                    ImGui::Text(buffer);
                }
            }
            ImGui::TreePop();
        }
    }

    void render() const
    {
        std::list<const hsm::State*> states = getCurrentStates();

        for (auto state : states)
        {
            ((const ImGuiHSMState*)state)->render();
        }

        renderExceptions(states);

        renderResources();
    }
};

void InitSDL()
{
    if (SDL_Init(SDL_INIT_EVERYTHING) < 0)
        return;
    
    // Set OpenGL profile and version MAJOR.MINOR.
    //SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, OPENGL_PROFILE);
    //SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, OPENGL_MAJOR_VERSION);
    //SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, OPENGL_MINOR_VERSION);
    //SDL_GL_SetAttribute(SDL_GL_CONTEXT_FLAGS, SDL_GL_CONTEXT_FORWARD_COMPATIBLE_FLAG);

    // Create SDL display window.
    displayWindow = SDL_CreateWindow("state machine", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_OPENGL);
    if (displayWindow == nullptr)
        return;

    context = SDL_GL_CreateContext(displayWindow);
    if (context == nullptr)
        return;

    // Must be after the context is assigned.
    const unsigned char *version = glGetString(GL_VERSION);
    if (version == nullptr)
        return;

    SDL_GL_MakeCurrent(displayWindow, context);
 }

void InitOpenGL()
{

    glShadeModel    (GL_SMOOTH);
    glClearColor    (0.0f, 0.0f, 0.0f, 1.0f);
    glClearDepth    (1.0f);
    glEnable        (GL_DEPTH_TEST);
    glDepthFunc     (GL_LEQUAL);
    glHint          (GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);
    glBlendFunc	    (GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glDisable       (GL_DEPTH_TEST);
    glDisable       (GL_LIGHTING);
    glDisable       (GL_CULL_FACE);
    glEnable        (GL_BLEND);
    glEnable        (GL_TEXTURE_2D);


    glViewport(0, 0, (GLsizei)SCREEN_WIDTH, (GLsizei)SCREEN_HEIGHT);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, SCREEN_WIDTH, 0, SCREEN_HEIGHT, -1.0, 1.0f);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
}

void InitImGui()
{
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;

    // Setup Dear ImGui style
    ImGui::StyleColorsDark();

    // Setup Platform/Renderer bindings
    // window is the SDL_Window*
    // contex is the SDL_GLContext
    ImGui_ImplSDL2_InitForOpenGL(displayWindow, context);
    ImGui_ImplOpenGL2_Init();
}

void Shutdown()
{
    ImGui_ImplOpenGL2_Shutdown();
    ImGui_ImplSDL2_Shutdown();
    ImGui::DestroyContext();

    SDL_Quit();
}

void Start()
{
    std::string filename = "xmls\\state_machine_ovr_hierarchical.xml";

    hsm::StateMachineXmlLoader state_machine_loader;

    if (!state_machine_loader.load(filename))
    {
        debug::logFatal("schema '%s' failed to load.", filename.c_str());

        exit(-1);
    }

    // copy the loaded schema.
    hsm::schema::StateMachine state_machine_schema = state_machine_loader.getSchema();

    state_machine_factory = new ImGuiHSMFactory();

    // the state machine.
    state_machine = new ImGuiHSMachine(state_machine_schema, state_machine_factory);

    state_machine->start();
}

void Update()
{
    ((ImGuiHSMachine*)state_machine)->update();
}

void Render()
{
    ((const ImGuiHSMachine*)state_machine)->render();
}

int main (int ArgCount, char **Args)
{
    InitSDL();
    InitOpenGL();
    InitImGui();

    Start();

    bool Running = true;
    while (Running)
    {
        SDL_Event Event;
        while (SDL_PollEvent(&Event))
        {
            ImGui_ImplSDL2_ProcessEvent(&Event);

            if (Event.type == SDL_QUIT)
                Running = false;

            if (Event.type == SDL_KEYDOWN && Event.key.keysym.sym == SDLK_ESCAPE)
                Running = false;

            if(Event.type == SDL_WINDOWEVENT && Event.window.event == SDL_WINDOWEVENT_CLOSE && Event.window.windowID == SDL_GetWindowID(displayWindow))
                Running = false;
        }

        ImGui_ImplOpenGL2_NewFrame();
        ImGui_ImplSDL2_NewFrame(displayWindow);
        ImGui::NewFrame();

        glViewport(0, 0, (GLsizei)SCREEN_WIDTH, (GLsizei)SCREEN_HEIGHT);

        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
        glOrtho(0, SCREEN_WIDTH, 0, SCREEN_HEIGHT, -1.0, 1.0f);

        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        Update();
        Render();

        ImGui::Render();
        ImGui_ImplOpenGL2_RenderDrawData(ImGui::GetDrawData());

        SDL_GL_SwapWindow(displayWindow);
    }
    
    Shutdown();

    return 0;
}
